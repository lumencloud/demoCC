sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/json/JSONModel",
    "sap/m/MessageToast",
    "sap/ui/core/Messaging",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator",
    "sap/ui/core/format/DateFormat",
    "sap/ui/model/Sorter"
], (Controller, JSONModel, MessageToast, Messaging, Filter, FilterOperator, DateFormat, Sorter) => {
    "use strict";

    /**
     * @typedef {sap.ui.base.Event} Event
     * @typedef {sap.ui.table.Table} Table
     * @typedef {sap.m.Button} Button
     * @typedef {sap.ui.model.odata.v4.Context} V4Context
     * @typedef {sap.m.DatePicker} DatePicker
     */
    return Controller.extend("bix.master.batch.controller.Main", {
        /**
         * 초기 메소드
         */
        onInit: function () {
            const myRoute = this.getOwnerComponent().getRouter().getRoute("RouteMain");
            myRoute.attachPatternMatched(this.onMyRoutePatternMatched, this);
        },

        /**
         * 배치 관리 페이지로 라우팅했을 때
         */
        onMyRoutePatternMatched: async function () {
            // 초기 모델 설정
            await this._setModel();

            // PL 선택
            this.byId("PLButton").firePress();

            // 테이블 바인딩
            this._bindTable();
        },

        /**
         * 초기 모델 설정
         */
        _setModel: async function () {
            // 초기 searchModel 설정
            this.getView().setModel(new JSONModel({ status: "all", category: "PL" }), "searchModel");

            // Select Model
            this.getView().setModel(new JSONModel([
                { value: "all", name: "전체" },
                { value: true, name: "성공" },
                { value: false, name: "실패" }
            ]), "codeModel");

            // 전체 연도에 대한 버전 목록 전역변수에 JSONModel로 담기
            let oModel = this.getOwnerComponent().getModel();
            let oCodeContext = oModel.bindContext("/interface_log_view", null, {
                $apply: "groupby((ver))",
                $orderby: 'ver desc',
            });
            let oVerData = await oCodeContext.requestObject();
            this.getView().setModel(new JSONModel(oVerData.value), "verModel");

            // 초기에 현재 연도에 대한 버전만 보이도록
            let sYear = this.byId("datePicker").getDateValue()?.getFullYear() || new Date().getFullYear();
            this.byId("version").getBinding("items").filter(
                new Filter("ver", FilterOperator.Contains, sYear),
            )
        },

        /**
         * 카테고리에 따른 테이블 바인딩
         */
        _bindTable: function () {
            let oSearchModel = this.getView().getModel("searchModel");
            let sCategory = oSearchModel.getProperty("/category");

            const aFilters = [];
            if (sCategory === "PL") {
                // 테이블 필터 추가
                const oTable = this.byId("batchTable");

                // 검색창 ver 선택 시 검색 조건 추가
                let sVer = oSearchModel.getProperty("/ver");
                if (sVer) {
                    aFilters.push(
                        new Filter("ver", FilterOperator.EQ, sVer),
                    )
                } else {
                    aFilters.push(
                        new Filter("ver", FilterOperator.NotContains, "TEST"),
                        new Filter("ver", FilterOperator.NE, null),
                    )
                }

                // 성공 여부 (전체가 아닐 때 적용)
                let isSuccess = oSearchModel.getProperty("/success_yn");
                if (isSuccess !== "all") {
                    aFilters.push(new Filter("success_yn", FilterOperator.EQ, isSuccess));
                }

                // 테이블 바인딩
                oTable.bindRows({
                    path: "/interface_log_view",
                    filters: aFilters,
                    parameters: {
                        $count: true,
                    },
                    events: {
                        dataRequested: function () {
                            oTable.setBusy(true);
                        }.bind(this),
                        dataReceived: function (oEvent) {
                            oTable.setBusy(false);
                        }.bind(this),
                    },
                });
            } else if (sCategory === "DealStage") {

            }
        },

        /**
         * 조회 버튼 클릭 이벤트
         */
        onSearch: function () {
            this._bindTable();
        },

        /**
         * 성공 여부 Select 변경 이벤트
         */
        onSelectionChange: function (oEvent) {
            this._bindTable();
        },

        /**
         * 기간 변경 이벤트
         * @param {Event} oEvent 
         */
        onDateChange: function (oEvent) {
            // 선택한 연도
            let dValue = /** @type {DatePicker} */ (oEvent.getSource()).getDateValue();
            let sYear = dValue.getFullYear();

            // version에 선택한 연도의 버전만 조회되도록 변경
            this.byId("version").getBinding("items").filter(
                new Filter("ver", FilterOperator.Contains, sYear),
            )

            // version 값 비우기
            this.byId("version").setValue(null);
        },

        /**
         * 상단 카테고리 토글버튼 클릭 이벤트
         * @param {*} oEvent 
         */
        onTogglePress: function (oEvent) {
            const oPressButton = oEvent.getSource()
            const oBox = oPressButton.getParent();
            const sPressedKey = oPressButton.getText();

            // const oSelect = this.byId("version");
            // oSelect.unbindItems();

            // 선택한 버튼을 제외하고는 pressed false로 변경
            oBox.getItems().forEach(function (oControl) {
                if (oControl instanceof sap.m.ToggleButton) {
                    const sKey = oControl.getText();
                    oControl.setPressed(sKey === sPressedKey);
                }
            })

            const oDatePicker = this.byId("datePicker");
            const isDealStage = sPressedKey === "DealStage";

            if (isDealStage) {
                oDatePicker.setDisplayFormat("yyyy-MM");
                oDatePicker.setValueFormat("yyyy-MM");

            } else {
                oDatePicker.setDisplayFormat("yyyy");
                oDatePicker.setValueFormat("yyyy");

                // 최소일자(2025년), 최대일자(현재 연도), 기본값(현재 연도)
                oDatePicker.setMinDate(new Date(2025, 0, 1));
                oDatePicker.setMaxDate(new Date());
                oDatePicker.setDateValue(new Date());
            }

            // 카테고리 설정
            this.getView().getModel("searchModel").setProperty("/category", sPressedKey);
        },

        /**
         * 확인 버튼 클릭 이벤트
         * @param {Event} oEvent 
         */
        onConfirm: function (oEvent) {
            // confirm_yn을 true로 변경
            let oButton = /** @type {Button} */ (oEvent.getSource());
            let oBindingContext = /** @type {V4Context} */ (oButton.getBindingContext());
            oBindingContext.setProperty("confirm_yn", true);
        },

        /**
         * 배치 그룹 테이블 상세 버튼 클릭 이벤트
         * @param {Event} oEvent 
         */
        onDetail: async function (oEvent) {
            let oContext = oEvent.getParameters()["rowContext"];

            if (oContext) {
                this.getOwnerComponent().getRouter().navTo("RouteDetail", {
                    ver: oContext.getObject("ver"),
                    if_step: oContext.getObject("if_step"),
                    table_name: oContext.getObject("table_name"),
                    procedure_name: oContext.getObject("procedure_name"),
                    success_yn: oContext.getObject("success_yn"),
                });
            }
        },
    });
});