sap.ui.define([
  "sap/ui/core/mvc/Controller"
], (BaseController) => {
  "use strict";

  return BaseController.extend("bix.master.orgtarget.controller.App", {
    onInit: function () {

    }
  });
});