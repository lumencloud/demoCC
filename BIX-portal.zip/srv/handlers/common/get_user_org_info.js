/**
 * 로그인한 사용자의 대표 조직
 * @param {Boolean} isTree 트리 형태로 반환할지 여부
 * @returns 
 */
module.exports = (srv) => {
    srv.on('get_user_org_info', async (req) => {

        const userInfo = req.user;
        let oInfo = {
            org_name: '',
            emp_no: '',
            auth: '',
            name: userInfo.attr.familyName + userInfo.attr.givenName
        };

        oInfo.emp_no = userInfo.attr?.emp_no?.[0];

        if (oInfo.emp_no) {
            const orgMap = await SELECT.one.columns('org_id').from('common_org_map').where({ 'emp_no': oInfo.emp_no, 'primary_status': 'Y', 'ver': SELECT.one.columns('ver').from('common_version').where({ 'tag': 'C' }) })
            if (orgMap) {
                const orgInfo = await SELECT.one.from('common_org').where({
                    'id': orgMap.ORG_ID,
                    'ver': SELECT.one.columns('ver').from('common_version').where({ 'tag': 'C' })
                });
                if (orgInfo) oInfo.org_name = orgInfo.NAME;
            }
        }

        if (userInfo.is("bix-portal-system-admin")) {
            oInfo.auth = "SYS ADMIN";
        } else if (userInfo.is("bix-portal-manage")) {
            oInfo.auth = "관리자";
        } else if (userInfo.is("bix-portal-company-viewer")) {
            oInfo.auth = "전사 조회";
        } else if (userInfo.is("bix-portal-user")) {
            oInfo.auth = "일반 사용자";
        }

        return oInfo;
    })
}