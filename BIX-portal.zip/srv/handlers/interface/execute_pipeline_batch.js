const { func } = require('@sap/cds/lib/ql/cds-ql');

module.exports = (srv) => {
    srv.on('execute_pipeline_batch', async (req) => {
        const { ver } = req.data;

        const tx = cds.tx(req);
        const db = await cds.connect.to('db');
        const common_version_sfdc = db.entities('common').version_sfdc;
        const common_interface_log = db.entities('common').interface_log;
        const common_if_project = db.entities('common').if_project;
        const common_project_platform = db.entities('common').project_platform;
        const pl_if_wideview = db.entities('pl').if_wideview;

        const now = new Date();
        const year = now.getFullYear().toString();
        const month = (now.getMonth()).toString().padStart(2, '0'); // 인터페이스 시점 직전 월

        try {
            const ver_info = await SELECT.one.from(common_version_sfdc).columns(ver).where({ tag: 'P' }).orderBy('ver desc');

            let ver_no = `P${year}${month}01`
            // 이번 달 최신 버전이 존재 할 경우, [최신 버전 + 1] 신규 버전코드 생성
            if (ver_info) {
                ver_no = ver_info.ver.substring(0, 7) + (Number(ver_info.ver.slice(7)) + 1).toString().padStart(2, '0');


                // [step-2 신규 버전코드 등록]
                await tx_ver.run(INSERT([{
                    if_id: func('SYSUUID')[0], ver: ver_no, year: year, month: month, tag: 'C'
                }]).into(common_version));

                await tx_ver.commit();
            } else {
                ver_no = ver;
            }

            let oData = {
                VER: ver,
                'cal_dt__c': '250425001'
            };

            await executeHttpRequest(
                oRequestInfo,
                {
                    method: 'post',
                    url: RCV_PARAM.api,
                    data: oData
                },
                {
                    fetchCsrfToken: true
                }
            ).then(res => {
                // 200 ok 로 에러메시지가 넘어오는 경우..
                if (res.data.returnCode === 'E') {
                    Insert_log(RCV_PARAM.if_step, RCV_PARAM.source, RCV_PARAM.table_name, RCV_PARAM.procedure_name, false, err.response?.data?.message?.slice(0, 500), err.response?.data?.message.match(/\[(\d+)\]/)?.[1] ?? null);
                    throw new Error(res.data?.message);
                }
            }).catch(err => {
                if (err.status === 500) {
                    Insert_log(RCV_PARAM.if_step, RCV_PARAM.source, RCV_PARAM.table_name, RCV_PARAM.procedure_name, false, err.response?.data?.message?.slice(0, 500), err.response?.data?.message.match(/\[(\d+)\]/)?.[1] ?? null);
                    throw new Error(err.response?.data?.message);
                } else {
                    let err_text = err.request.path + ' -- ' + err.request.method + ' -- ' + err.message + ' -- ' + err.stack;
                    Insert_log(RCV_PARAM.if_step, RCV_PARAM.source, RCV_PARAM.table_name, RCV_PARAM.procedure_name, false, err_text.slice(0, 500), null);
                    throw new Error(err_text);
                }
            });

            await tx_trsf.run(`CALL ${TRSF_PARAM.procedure_name}( VER => '${ver_no}', O_RESULT => ? )`)
                .then(res => {
                    if (res.O_RESULT.find(o => o.RESULT_CODE === 'NG')) {
                        throw new Error(res.O_RESULT.find(o => o.RESULT_CODE === 'NG').SQL_ERROR_MESSAGE);
                    }
                })
                .catch(err => {
                    // Insert_log(TRSF_PARAM.if_step, TRSF_PARAM.source, TRSF_PARAM.table_name, RCV_PARAM.procedure_name, false, err.message?.slice(0, 500), err.code);
                    throw new Error(err);
                });


        } catch (err) {

        }


    })

    // return oReturn;
}
