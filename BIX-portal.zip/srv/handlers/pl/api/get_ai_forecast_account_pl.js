const check_user_auth = require('../../function/check_user_auth');

module.exports = (srv) => {
    srv.on('get_ai_forecast_account_pl', async (req) => {
        /**
         * 핸들러 초기에 권한체크
         */
        await check_user_auth(req);

        // function 호출 리턴 객체
        const aRes = [];

        // cds 모듈을 통한 DB 커넥트
        const db = await cds.connect.to('db');

        /**
         * pl.wideview_org_view [실적]
         * [부문/본부/팀 + 연월,금액] 팀,본부 단위의 프로젝트 실적비용 집계 뷰
         */
        const pl_view = db.entities('pl').pipeline_view;
        /**
         * common.org_full_level_view [조직정보]
         * 조직구조 테이블
         */
        const org_full_level = db.entities('common').org_full_level_view;

        // function 입력 파라미터
        const { year, month, org_id } = req.data;
        /**
         * org_id 파라미터값으로 조직정보 조회
         * 
         */
        const org_col = `case
            when lv1_id = '${org_id}' THEN 'lv1_id'
            when lv2_id = '${org_id}' THEN 'lv2_id'
            when lv3_id = '${org_id}' THEN 'lv3_id'
            when div_id = '${org_id}' THEN 'div_id'
            when hdqt_id = '${org_id}' THEN 'hdqt_id'
            when team_id = '${org_id}' THEN 'team_id'
            end as org_level`;
        let orgInfo = await SELECT.one.from(org_full_level).columns([org_col, 'org_ccorg_cd', 'org_name'])
            .where`org_id = ${org_id} and (lv1_id = ${org_id} or lv2_id = ${org_id} or lv3_id = ${org_id} or div_id = ${org_id} or hdqt_id = ${org_id} or team_id = ${org_id})`;

        if (!orgInfo) return '조직 조회 실패'; // 화면 조회 시 유효하지 않은 조직코드 입력시 예외처리 추가 필요 throw error
        let org_col_nm = orgInfo.org_level;

        let pl_col_list = [
            'biz_tp_account_cd',
            'biz_tp_account_nm',
            'deal_stage_cd',
            'biz_opp_nm',
            'biz_opp_no',
            'cls_rsn_tp_cd',
            'cls_rsn_tp_nm',
            'deal_stage_chg_dt',
            `ifnull(rodr_year_amt,0)/100000000 as rodr_year_amt`
        ];
        let s_first_day = new Date(year, month, 1).getDate().toString().padStart(2, '0'),
            s_last_day = new Date(year, month, 0).getDate().toString().padStart(2, '0');
        let s_first_date = `${year}-${month}-${s_first_day}`
        let s_last_date = `${year}-${month}-${s_last_day}`
        let s_order_by = `rodr_year_amt desc`
        //,deal_stage_cd:{in:['Deal Lost','Deselected']}
        //
        let pl_where_conditions = { year: year, deal_stage_cd: { in: ['Deal Lost', 'Deselected'] }, deal_stage_chg_dt: { between: s_first_date, and: s_last_date }, weekly_yn: true }
        let pl_where = org_col_nm === 'lv1_id' ? pl_where_conditions : { ...pl_where_conditions, [org_col_nm]: org_id }

        const [pl_data] = await Promise.all([
            SELECT.from(pl_view).columns(pl_col_list).where(pl_where).orderBy(s_order_by)
        ])
        let lost_pl = pl_data.filter(pl => pl.deal_stage_cd === 'Deal Lost'),
            deselected_pl = pl_data.filter(pl => pl.deal_stage_cd === 'Deselected');

        let o_result = { lost: {}, deselected: {} }
        lost_pl.forEach((pl, i) => {
            if (i < 5) {
                o_result.lost[`${pl.biz_opp_no}`] = {
                    biz_opp_nm: pl.biz_opp_nm,
                    biz_tp_account_nm: pl.biz_tp_account_nm,
                    cls_rsn_tp_nm: pl.cls_rsn_tp_nm,
                    rodr_amt: pl.rodr_year_amt
                }
            } else {
                if (!o_result[`lost_etc`]) {
                    o_result[`lost_etc`] = {
                        biz_opp_nm: pl.biz_opp_nm,
                        biz_tp_account_nm: pl.biz_tp_account_nm,
                        cls_rsn_tp_nm: '',
                        rodr_amt: pl.rodr_year_amt,
                        rodr_cnt: 1
                    }
                }
                o_result[`lost_etc`]['rodr_amt'] += pl.rodr_year_amt
                o_result[`lost_etc`]['rodr_cnt']++
            }
        })
        deselected_pl.forEach((pl, i) => {
            if (i < 5) {
                o_result.deselected[`${pl.biz_opp_no}`] = {
                    biz_opp_nm: pl.biz_opp_nm,
                    biz_tp_account_nm: pl.biz_tp_account_nm,
                    cls_rsn_tp_nm: pl.cls_rsn_tp_nm,
                    rodr_amt: pl.rodr_year_amt
                }
            } else {
                if (!o_result[`deselected_etc`]) {
                    o_result[`deselected_etc`] = {
                        biz_opp_nm: pl.biz_opp_nm,
                        biz_tp_account_nm: pl.biz_tp_account_nm,
                        cls_rsn_tp_nm: '',
                        rodr_amt: pl.rodr_year_amt,
                        rodr_cnt: 1
                    }
                }
                o_result[`deselected_etc`]['rodr_amt'] += pl.rodr_year_amt
                o_result[`deselected_etc`]['rodr_cnt']++
            }
        })

        let a_lost = Object.values(o_result.lost).sort((a, b) => b["rodr_amt"] - a["rodr_amt"])
        let a_deselected = Object.values(o_result.deselected).sort((a, b) => b["rodr_amt"] - a["rodr_amt"])
        if(!!o_result[`lost_etc`]){
            a_lost.push(o_result[`lost_etc`])
        }
        if(!!o_result[`deselected_etc`]){
            a_deselected.push(o_result[`deselected_etc`])
        }
        aRes.push({ lost: a_lost }, { deselected: a_deselected })

        return aRes;
    })
}