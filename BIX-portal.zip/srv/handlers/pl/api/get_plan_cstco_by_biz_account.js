module.exports = (srv) => {
    srv.on('get_plan_cstco_by_biz_account', async (req) => {

        /**
         * API 리턴값 담을 배열 선언
         */
        let o_result = {};

        // cds 모듈을 통한 DB 커넥트
        const db = await cds.connect.to('db');

        // =========================== 조회 대상 DB 테이블 ===========================
        // entities('<cds namespace 명>').<cds entity 명>
        // srv .cds 에 using from 구문에 엔티티가 속한 db .cds 파일이 최소 한 번이라도 걸려있어야 db.entities 로 엔티티 인식가능
        // (서비스에 등록할 필요는 없음)
        /**
         * BR [실적]
         */
        const pl_wideview_view = db.entities('pl').wideview_view;

        /**
         * common.annual_target_temp_view [연 목표 정보]
         * 목표 테이블
         */
        const customer_view = db.entities("common").customer;

        /**
         * common.org_full_level_view [조직정보]
         * 조직구조 테이블
         */
        const org_full_level = db.entities('common').org_full_level_view;

        // function 입력 파라미터
        const { year, org_id, account_cd } = req.data;
        const last_year = (Number(year) - 1).toString();

        /**
         * org_id 파라미터값으로 조직정보 조회 및 버전 확인
         */
        const org_col = `case
            when lv1_id = '${org_id}' THEN 'lv1_ccorg_cd'
            when lv2_id = '${org_id}' THEN 'lv2_ccorg_cd'
            when lv3_id = '${org_id}' THEN 'lv3_ccorg_cd'
            when div_id = '${org_id}' THEN 'div_ccorg_cd'
            when hdqt_id = '${org_id}' THEN 'hdqt_ccorg_cd'
            when team_id = '${org_id}' THEN 'team_ccorg_cd'
            end as org_level`;
        const [orgInfo] = await Promise.all([
            SELECT.one.from(org_full_level).columns([org_col, 'org_ccorg_cd', 'org_name']).where({ 'org_id': org_id }),
        ]);

        if (!orgInfo) return '조직 조회 실패'; // 화면 조회 시 유효하지 않은 조직코드 입력시 예외처리 추가 필요 throw error

        // pl_wideview_view 설정
        const pl_column = ['cstco_cd',
            `sum(case when src_type not in ('WA', 'D') then ifnull(sale_year_amt, 0) else 0 end) as sale_secured`,
            `sum(case when src_type = 'D' then ifnull(sale_year_amt, 0) else 0 end) as sale_not_secured`,
            `sum(case when src_type not in ('WA', 'D') then ifnull(sale_year_amt, 0) else 0 end)
                + sum(case when src_type = 'D' then ifnull(sale_year_amt, 0) else 0 end) as sale_forecast`,

                `sum(case when src_type not in ('WA', 'D') then ifnull(margin_year_amt, 0) else 0 end) as margin_secured`,
                `sum(case when src_type = 'D' then ifnull(margin_year_amt, 0) else 0 end) as margin_not_secured`,
                `sum(case when src_type not in ('WA', 'D') then ifnull(margin_year_amt, 0) else 0 end)
                    + sum(case when src_type = 'D' then ifnull(margin_year_amt, 0) else 0 end) as margin_forecast`,
            ];
        const pl_where = { 'year': year, [orgInfo.org_level]: orgInfo.org_ccorg_cd, biz_tp_account_cd: account_cd };
        const pl_groupBy = ['cstco_cd'];

        // customer 설정
        const customer_column = ["code", "name"];

        // DB 쿼리 실행 (병렬)
        let [pl_data, customer_data] = await Promise.all([
            SELECT.from(pl_wideview_view).columns(pl_column).where(pl_where).groupBy(...pl_groupBy),
            SELECT.from(customer_view).columns(customer_column),
        ]);

        // PL 데이터에 고객사 이름 붙이기
        pl_data.forEach(o_pl_data => {
            return o_pl_data["cstco_name"] = customer_data.find(o_customer_data => o_customer_data.code === o_pl_data.cstco_cd)?.name;
        })

        // 고객사명 없는 데이터 제거
        pl_data = pl_data.filter(o_pl_data => !!o_pl_data.cstco_name);

        // 연간 추정을 기준으로 상위 5개의 항목만 
        let a_sale_data = pl_data.sort((oItem1, oItem2) => oItem2.sale_forecast - oItem1.sale_forecast).slice(0, 5);
        let a_margin_data = pl_data.sort((oItem1, oItem2) => oItem2.margin_forecast - oItem1.margin_forecast).slice(0, 5);

        // 데이터 가공
        o_result["sale"] = a_sale_data.map(o_curr_data => {
            return {
                secured: o_curr_data.sale_secured,
                not_secured: o_curr_data.sale_not_secured,
                forecast: o_curr_data.sale_forecast,
                name: o_curr_data.cstco_name,
            }
        })

        o_result["margin"] = a_margin_data.map(o_curr_data => {
            return {
                secured: o_curr_data.margin_secured,
                not_secured: o_curr_data.margin_not_secured,
                forecast: o_curr_data.margin_forecast,
                name: o_curr_data.cstco_name,
            }
        })

        return o_result;
    });
}