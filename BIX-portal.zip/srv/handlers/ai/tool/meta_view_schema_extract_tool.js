const cds = require('@sap/cds');
const { createLogger } = require('../util/logger');

class MetaViewSchemaExtractTool {
    constructor() {
        this.logger = createLogger('meta-view-schema-extract-tool');
    }

    /**
     * 뷰 테이블 스키마 조회
     * @param {Object} inputs
     * @param {string} inputs.table_name - 조회할 테이블명
     */
    async execute(inputs) {
        try {
            const { table_name } = inputs;

            if (!table_name) {
                throw new Error('table_name is required');
            }
            
            this.logger.info(`뷰 스키마 조회: ${table_name}`);
            
            const db = await cds.connect.to('db');
            
            // 테이블 정보 조회
            const tableQuery = `
                SELECT NAME
                     , KOR_NAME
                     , DESCRIPTION 
                  FROM METASTORE_TABLE 
                 WHERE NAME = ?
                   AND IS_AI_TARGET = TRUE
            `;
            
            // 컬럼 정보 조회  
            const columnQuery = `
                SELECT c.NAME
                     , c.KOR_NAME
                     , c.DESCRIPTION
                     , c.DATA_TYPE
                     , c.TERM_NAME
                     , t.DESCRIPTION as TERM_DESCRIPTION
                  FROM METASTORE_COLUMN c
                  LEFT JOIN METASTORE_TERM t
                         ON c.TERM_NAME = t.NAME
                 WHERE c.TABLE_NAME = ?
                   AND c.IS_AI_TARGET = TRUE
                 ORDER BY NAME
            `;
            
            const [tableInfo, columns] = await Promise.all([
                db.run(tableQuery, [table_name]),
                db.run(columnQuery, [table_name])
            ]);
            
            // 테이블이 없어도 빈 결과 반환
            if (tableInfo.length === 0) {
                this.logger.warn(`테이블을 찾을 수 없음: ${table_name}`);
                return JSON.stringify({ table: null, columns: [] }, null, 2);
            }

            const result = {
                table: this.buildTableInfo(tableInfo[0]),
                columns: columns.map(col => this.buildColumnInfo(col)).filter(col => col !== null)
            };
            
            this.logger.info(`뷰 스키마 조회 완료: ${columns.length}개 컬럼`);
            return JSON.stringify(result, null, 2);
        } catch (error) {
            this.logger.error('뷰 스키마 조회 실패:', error);
            throw error;
        }
    }

    /**
     * 테이블 정보 구성 (null 값 제외)
     * @param {Object} tableData - 테이블 데이터
     * @returns {Object} 테이블 정보
     */
    buildTableInfo(tableData) {
        const info = {};
        
        if (tableData.NAME) info.name = tableData.NAME;
        if (tableData.KOR_NAME) info.korean_name = tableData.KOR_NAME;
        if (tableData.DESCRIPTION) info.description = tableData.DESCRIPTION;
        
        return info;
    }

    /**
     * 컬럼 정보 구성 (null 값 제외)
     * @param {Object} columnData - 컬럼 데이터
     * @returns {Object|null} 컬럼 정보 (필수 필드가 없으면 null 반환)
     */
    buildColumnInfo(columnData) {
        // 필수 필드 체크
        if (!columnData.NAME) {
            return null;
        }

        const info = {
            name: columnData.NAME
        };
        
        // 선택적 필드들 (값이 있을 때만 추가)
        if (columnData.KOR_NAME) info.korean_name = columnData.KOR_NAME;
        if (columnData.DESCRIPTION) info.description = columnData.DESCRIPTION;
        if (columnData.DATA_TYPE) info.data_type = columnData.DATA_TYPE;
        
        // 용어 정보 (값이 있을 때만 추가)
        if (columnData.TERM_NAME) info.term_name = columnData.TERM_NAME;
        if (columnData.TERM_DESCRIPTION) info.term_description = columnData.TERM_DESCRIPTION;
        
        return info;
    }
}

module.exports = MetaViewSchemaExtractTool;