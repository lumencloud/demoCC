/**
 * AI Agent 설정 매개변수
 */
// 현재 환경
const ENV = process.env.NODE_ENV || 'dev';

// 비즈니스 컨텍스트 정보
const BUSINESS_CONTEXT_SETTINGS = {
    baseInfo: `회사: SK(주) AX (IT SI 기업)
시스템: 차세대 경영정보 시스템 (SAP BTP 기반)
목적: 전사 실적 데이터 통합 및 AI 기반 의사결정 지원
핵심 시스템: ERP, PROMIS(프로젝트 관리), SFDC(영업관리)
주요 모듈: PL 장표, SG&A 관리, 투자상품 관리, AI 시뮬레이션
데이터 흐름: PROMIS→ERP 원가 데이터, SFDC→BTP 영업 데이터 연계
운영 방식: 실적 기반 운영 (추정 데이터 최소화)

당월 실적: 2025년(현재) 당월까지의 누계 실적
전년 동기 실적: 전년도 동기의 누계 실적
GAP: 당월 누계 실적과 전년 동기 누계 실적의 차이
Account: 고객사들을 유사한 특성으로 묶은 그룹 단위` // metastore 적용되면 없어질 부분
};

// 로그 설정
const LOGGING_SETTINGS = {
    // 로그 모듈명 설정
    moduleNames: {
        general: 'AI-AGENT',    // INFO, WARN용
        detailed: 'AI-AGENT'    // ERROR, DEBUG용 접두사 (실제로는 AI-AGENT_클래스명)
    },
    // 로그 레벨별 설정
    levels: {
        enableDebug: true,
        enableInfo: true,
        enableWarn: true,
        enableError: true
    }
};

// 진행률 설정
const PROGRESS_SETTINGS = {
    masterAgentComplete: 10,
    agentSelected: 50,
    agentExecuted: 70,
    resultGenerated: 90
};

// 마스터 에이전트 설정
const MASTER_AGENT_SETTINGS = {
    // 템플릿 정보
    template: {
        name: 'master-agent-test',
        scenario: 'foundation-models',
        version: '0.0.1'
    },

    // 폴백 설정 추가
    fallback: {
        default_agent: 'general_qa_agent',
        retry_attempts: 3,
        timeout_ms: 30000
    },

    // 모델 설정
    model: {
        dev: {
            model_name: 'gpt-4.1-mini',
            temperature: 0.3,
            max_tokens: 1000,
            model_version: '2025-04-14'
        },
        stag: {
            model_name: 'gemini-1.5-flash',
            temperature: 0.3,
            max_tokens: 1000,
            model_version: '002'
        },
        prod: {
            model_name: 'gpt-4.1-mini',
            temperature: 0.3,
            max_tokens: 1000,
            model_version: '2025-04-14'
        }
    }
};

// 에이전트 분류 설정
const AGENT_CLASSIFICATION_SETTINGS = {
    directLlm: ['visualization_agent'],
    generalQa: ['general_qa_agent'],
    quickAnswer: ['quick_answer_agent'],
    navigation: ['navigator_agent'],
    analysis: ['analysis_agent']
};

// 메뉴 설정
const MENU_SETTINGS = {
    // 기본값 설정
    defaults: {
        org_id: '5'
    },
    
    // item 코드와 한글명 매핑
    itemCodeNames: {
        'org': '조직',
        'account': 'account',
        'relsco': '대내/대외',
        'crov': '신규/이월',
        'task': '과제',
        'lob': 'LOB',
        'deal_stage': 'Deal Stage 기준',
        'month': '월 기준',
        'rodr': '수주금액 기준',
        'member_year': '멤버사 연도별 합계',
        'task_year': '과제 연도별 합계'
    }
};

// 데이터 조회 설정 
const DATA_FETCHER_SETTINGS = {
    apis: {
        'get_actual_sale_org_pl': {
            description: '실적PL 매출/마진-조직별 데이터 조회',
            params: ['year', 'month', 'org_id'],
            handlerPath: '../../pl/api/get_actual_sale_org_pl'
        },
        'get_actual_sale_account_pl': {
            description: '실적PL 매출/마진-Account 데이터 조회',
            params: ['year', 'month', 'org_id'],
            handlerPath: '../../pl/api/get_actual_sale_account_pl'
        },
        'get_actual_sale_relsco_pl': {
            description: '실적PL 매출/마진-대내/대외 데이터 조회',
            params: ['year', 'month', 'org_id'],
            handlerPath: '../../pl/api/get_actual_sale_relsco_pl'
        },
        'get_actual_sale_crov_pl': {
            description: '실적PL 매출/마진-신규/이월 조회',
            params: ['year', 'month', 'org_id'],
            handlerPath: '../../pl/api/get_actual_sale_crov_pl'
        },
        'get_actual_sga': {
            description: '실적PL SG&A 데이터 조회',
            params: ['year', 'month', 'org_id'],
            handlerPath: '../../sga/api/get_actual_sga'
        },
        'get_actual_dt_org_oi': {
            description: '실적PL DT 매출-조직별 조회',
            params: ['year', 'month', 'org_id'],
            handlerPath: '../../pl/api/get_actual_dt_org_oi'
        },
        'get_actual_dt_account_oi': {
            description: '실적PL DT 매출-Account 조회',
            params: ['year', 'month', 'org_id'],
            handlerPath: '../../pl/api/get_actual_dt_account_oi'
        },
        'get_actual_br_org_detail': {
            description: '실적PL BR 조회',
            params: ['year', 'month', 'org_id'],
            handlerPath: '../../pl/api/get_actual_br_org_detail'
        },
        'get_actual_rohc_org_oi': {
            description: '실적PL RoHC 조회',
            params: ['year', 'month', 'org_id'],
            handlerPath: '../../pl/api/get_actual_rohc_org_oi'
        },
        'get_forecast_m_pl': {
            description: '월별 추정 미확보PL 데이터 조회',
            params: ['year', 'month', 'org_id'],
            handlerPath: '../../pl/api/get_forecast_m_pl'
        },
        'get_forecast_pl_pipeline_detail': {
            description: '추정PL 전사 Pipeline 상세 조회',
            params: ['year', 'month', 'org_id'],
            handlerPath: '../../pl/api/get_forecast_pl_pipeline_detail'
        },
        'get_forecast_pl_pipeline_org_detail': {
            description: '추정PL 부문 Pipeline 상세 조회',
            params: ['year', 'month', 'org_id'],
            handlerPath: '../../pl/api/get_forecast_pl_pipeline_org_detail',
            category: 'forecast_pl',
            tags: ['forecast', 'pipeline']
        },
        'get_forecast_pl_sale_margin_org_detail': {
            description: '추정PL 매출/마진-조직별 조회',
            params: ['year', 'month', 'org_id'],
            handlerPath: '../../pl/api/get_forecast_pl_sale_margin_org_detail'
        },
        'get_forecast_pl_sale_margin_account_detail': {
            description: '추정PL 매출/마진-Account 조회',
            params: ['year', 'month', 'org_id'],
            handlerPath: '../../pl/api/get_forecast_pl_sale_margin_account_detail'
        },
        'get_forecast_pl_sale_margin_crov_detail': {
            description: '추정PL 매출/마진-대내/대외 조회',
            params: ['year', 'month', 'org_id'],
            handlerPath: '../../pl/api/get_forecast_pl_sale_margin_crov_detail'
        },
        'get_forecast_pl_sale_margin_relsco_detail': {
            description: '추정PL 매출/마진-신규/이월 조회',
            params: ['year', 'month', 'org_id'],
            handlerPath: '../../pl/api/get_forecast_pl_sale_margin_relsco_detail'
        },
        'get_forecast_dt_org_oi': {
            description: '추정PL DT 매출-조직별 조회',
            params: ['year', 'month', 'org_id'],
            handlerPath: '../../pl/api/get_forecast_dt_org_oi'
        },
        'get_forecast_dt_account_oi': {
            description: '추정PL DT 매출-Account 조회',
            params: ['year', 'month', 'org_id'],
            handlerPath: '../../pl/api/get_forecast_dt_account_oi'
        },
        'get_forecast_br_org_detail': {
            description: '추정PL BR 조회',
            params: ['year', 'month', 'org_id'],
            handlerPath: '../../pl/api/get_forecast_br_org_detail'
        },
        'get_forecast_pl_pipeline_account': {
            description: '추정PL Account 상세 조회',
            params: ['year', 'month', 'org_id'],
            handlerPath: '../../pl/api/get_forecast_pl_pipeline_account',
            category: 'forecast_pl',
            tags: ['forecast', 'pipeline']
        }
    },
    defaultParams: {
        year: new Date().getFullYear(),
        month: new Date().getMonth() + 1,
        org_id: '5' // MENU_SETTINGS의 기본값과 연동
    }
};

// 에이전트별 현재 환경에 맞는 모델 설정 가져오기
const getModelConfig = (agent) => {
    const envConfig = agent.model[ENV] || agent.model.dev;
    return { ...envConfig };
};
  
module.exports = {
    // 비즈니스 컨텍스트 설정
    businessContext: BUSINESS_CONTEXT_SETTINGS,

    // 로깅 관련 설정
    logging: LOGGING_SETTINGS,

    // 진행률 관련 설정
    progress: PROGRESS_SETTINGS,
    
    // 마스터 에이전트 관련 설정
    masterAgent: {
        templates: {
            masterAgent: MASTER_AGENT_SETTINGS.template
        },
        models: {
            masterAgent: getModelConfig(MASTER_AGENT_SETTINGS)
        },
        fallback: {
            masterAgent: MASTER_AGENT_SETTINGS.fallback
        },
        rawSettings: {
            masterAgent: MASTER_AGENT_SETTINGS
        }
    },
    
    // 개별 에이전트 설정
    agentClassification: AGENT_CLASSIFICATION_SETTINGS,

    // 메뉴 관련 설정
    menu: {
        settings: MENU_SETTINGS
    },

    // 데이터 조회 관련 설정 
    dataFetcher: DATA_FETCHER_SETTINGS,

    // 공통 유틸리티 
    utils: {
        getModelConfig
    }
};